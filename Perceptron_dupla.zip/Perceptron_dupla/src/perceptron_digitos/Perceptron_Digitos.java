package perceptron_digitos;
/**
 *
 * @author Clarimundo
 */
public class Perceptron_Digitos {

    public static void main(String[] args) {
         InterfacePerceptron prc = new InterfacePerceptron();
    }
    
}
