package perceptron_digitos;

/**
 *
 * @author Clarimundo
 */
public class Validacao {

    public Validacao() {

    }

    public double somatorio(int mat[][], double w[][]) {

        double yent = 0;
        double entrada[] = new double[16];
        int l = 1;
        entrada[0] = 1;
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 3; j++) {
                entrada[l] = mat[i][j];
                l++;
            }
        }
        for (int k = 0; k < 4; k++) {
            for (int j = 0; j < 16; j++) {
                yent = yent + entrada[j] * w[j][k];
            }
        }
        return yent;
    }

    public double saida(double yent, double limiar) {
        double f;

        if (yent > limiar) {
            f = 1;
        } else {
            f = -1;
        }
        return f;
    }

    public String teste(int mat[][], double w[][], double t[][], double limiar) {

        double f[] = {0, 0, 0, 0};

        for (int i = 0; i < 4; i++) {
            double yent = somatorio(mat, w);
            f[i] = saida(yent, limiar);
        }
        
        System.out.println(f.toString());

        //{1, -1, -1, -1}
        if (f[0] == 1 && f[1] == -1 && f[2] == -1 && f[3] == -1) {
            return "0";
        }

        //{-1, 1, -1, -1}
        if (f[0] == -1 && f[1] == 1 && f[2] == -1 && f[3] == -1) {
            return "1";
        }

        //{-1, -1, 1, -1}
        if (f[0] == -1 && f[1] == 1 && f[2] == -1 && f[3] == -1) {
            return "2";
        }

        //{-1, -1, -1, 1}
        if (f[0] == -1 && f[1] == 1 && f[2] == -1 && f[3] == -1) {
            return "3";
        }

        //{1, 1, -1, -1}
        if (f[0] == 1 && f[1] == 1 && f[2] == -1 && f[3] == -1) {
            return "4";
        }

        //{1, -1, 1, -1}
        if (f[0] == 1 && f[1] == -1 && f[2] == 1 && f[3] == -1) {
            return "5";
        }

        //{1, -1, -1, 1}
        if (f[0] == 1 && f[1] == -1 && f[2] == -1 && f[3] == 1) {
            return "6";
        }

        //{-1, 1, 1, -1}
        if (f[0] == -1 && f[1] == 1 && f[2] == 1 && f[3] == -1) {
            return "7";
        }

        //{-1, 1, -1, 1}
        if (f[0] == -1 && f[1] == 1 && f[2] == -1 && f[3] == 1) {
            return "8";
        }

        //{-1, -1, 1, 1}
        if (f[0] == -1 && f[1] == -1 && f[2] == 1 && f[3] == 1) {
            return "9";
        }
        return "-1";
    }
}
