package perceptron_digitos;

/**
 *
 * @author Clarimundo
 */
public class Aprendizagem {

//        private double x[][]={{1,1,1,1,1,0,1,1,0,1,1,0,1,1,1,1},
//                          {1,0,1,0,1,1,0,0,1,0,0,1,0,1,1,1}};
//   
//        private double w[]= new double [16];
//        private double t[]={1,-1};
    private double x[][] = {
        {1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1}, // 0
        {1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 0, 1, 0, 1, 1, 1}, // 1
        {1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1}, // 2
        {1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1}, // 3
        {1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1}, // 4
        {1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 1, 1, 1, 1}, // 5
        {1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1}, // 6
        {1, 1, 1, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1}, // 7
        {1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1}, // 8
        {1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1} // 9
    };

    private double w[][] = new double[16][4];

    private double t[][] = {
        {1, -1, -1, -1}, // Target for 0
        {-1, 1, -1, -1}, // Target for 1
        {-1, -1, 1, -1}, // Target for 2
        {-1, -1, -1, 1}, // Target for 3
        {1, 1, -1, -1}, // Target for 4
        {1, -1, 1, -1}, // Target for 5
        {1, -1, -1, 1}, // Target for 6
        {-1, 1, 1, -1}, // Target for 7
        {-1, 1, -1, 1}, // Target for 8
        {-1, -1, 1, 1} // Target for 9
    };

    private int epocas;

    public Aprendizagem() {
        epocas = 0;
    }

    public double[][] getw() {
        return w;
    }

    public double[][] gett() {
        return t;
    }

    public int getepocas() {
        return epocas;
    }

    public double somatorio(int i, int k) {
        double yent = 0;
        //Adicionado 4 neuronios no somatório
        for (int j = 0; j < 16; j++) {
            yent = yent + x[i][j] * w[j][k];
        }

        return yent;
    }

    public double saida(double yent, double limiar) {
        double f;

        if (yent > limiar) {
            f = 1;
        } else if (yent < -limiar) {
            f = -1;
        } else {
            f = 0;
        }
        return f;
    }

    // t double[10][4]
    public void atualiza(double alfa, double f[], int i) {
        for (int k = 0; k < 4; k++) {
            for (int j = 0; j < 16; j++) {
                w[j][k] = w[j][k] + alfa * (t[i][k] - f[k]) * x[i][j];
            }
        }
    }

    public void algoritmo(double alfa, double limiar) {
        double yent;
        double f[] = {0, 0, 0, 0};
        boolean mudou;

        for (int k = 0; k < 4; k++) {
            for (int j = 0; j < 16; j++) // zerar os pesos
            {
                w[j][k] = 0;
            }
        }

        do {
            mudou = false;
            for (int i = 0; i < 10; i++) { // define os padroes de entrada 0 a 9
                for (int k = 0; k < 4; k++) {   // define os neuronios
                    yent = somatorio(i, k);
                    f[k] = saida(yent, limiar);
                }
                
                for (int k = 0; k < 4; k++) {
                    if (f[k] != t[i][k]) {
                        mudou = true;
                    }
                }
                
                if (mudou == true) {
                    atualiza(alfa, f, i);
                }
            }
            epocas++;
        } while (mudou == true);
    }
}
